/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 0
   ------------------------------------------------------------------------------- */

vuser_init()
{

	web_url("canonical.html", 
		"URL=http://detectportal.firefox.com/canonical.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t77.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("canonical.html_2", 
		"URL=http://detectportal.firefox.com/canonical.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t78.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("r3.o.lencr.org", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t79.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x038.\\xEF\\xAAG\\x99\\xEE\\xC7\\xD7\\xE9\\xBE\\xB7o\\xBBfr\\xB6", 
		LAST);

	web_url("canonical.html_3", 
		"URL=http://detectportal.firefox.com/canonical.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t80.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("r3.o.lencr.org_2", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t81.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x03\\x0F\\xE5\\x1A\\x0E}\\x8A\\xBD\\x03\\x1F\\x8E\\x80I\\xDE\\x03\\x90\\xEC_", 
		LAST);

	web_url("blazedemo.com", 
		"URL=https://blazedemo.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t82.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("ocsp.digicert.com", 
		"URL=http://ocsp.digicert.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t83.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x01\\xE0c\\x8B\\x9A\\xDF\\x9CB\\x9B\\x90\\xA4n\\xB9\\x86\\x06\\x06", 
		LAST);

	web_custom_request("ocsp.digicert.com_2", 
		"URL=http://ocsp.digicert.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t84.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x06'd\\xBD\\xAC\\x97O,\nP\\xA8l\\xF3\\xF9\\x00\\xA6", 
		LAST);

	web_websocket_send("ID=0", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1708747029726\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	web_websocket_connect("ID=0", 
		"URI=wss://aus5.mozilla.org/update/6/Firefox/123.0/20240213221259/WINNT_x86_64-msvc-x64/en-GB/release/Windows_NT%252010.0.0.0.19045.3324%2520(x64)/ISET%3ASSE4_2%2CMEM%3A12287/default/default/update.xml?force=1", 
		"Origin=wss://push.services.mozilla.com/", 
		"SecWebSocketExtensions=permessage-deflate", 
		"OnOpenCB=OnOpenCB0", 
		"OnMessageCB=OnMessageCB0", 
		"OnErrorCB=OnErrorCB0", 
		"OnCloseCB=OnCloseCB0", 
		LAST);

	web_custom_request("aded6d3b-4eda-40af-8d0e-f3916d2b5e92", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/events/1/aded6d3b-4eda-40af-8d0e-f3916d2b5e92", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t86.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":6,\"start_time\":\"2024-02-24T09:58:22.000+05:30\",\"end_time\":\"2024-02-24T09:59:08.003+05:30\",\"reason\":\"startup\",\"experiments\":{\"ech-roll-out\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"backgroundupdate-enable-unelevated-installations-rollout-3-release\":{\"branch\":\"enabled\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"extensions-migration-in-import-wizard-116-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}"
		"},\"mozillaaccounts-toolbar-button-default-visibility-existing-user\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"launch-firefox-on-os-restart-treatment-a-rollout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"device-migration-q4-spotlights-remaining-population\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"add-an-image-to-pdf-with-alt-text-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\""
		"picture-in-picture-first-time-use-callout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"spocs-endpoint-rollout-release\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"upgrade-spotlight-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"fox-guide-reader-mode-existing-user-part-2\":{\"branch\":\"treatment-d\",\"extra\":{"
		"\"type\":\"nimbus-nimbus\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"56.1.0\",\"windows_build_number\":19045,\"architecture\":\"x86_64\",\"os\":\"Windows\",\"app_build\":\"20240213221259\",\"locale\":\"en-GB\",\"app_channel\":\"release\",\"os_version\":\"10.0\",\"app_display_version\":\"123.0\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\"first_run_date\":\"2023-02-13+05:30\",\"client_id\":\"b15c2122-a8ac-496f-a186-095bffc440f6\"},\"metrics\":{\"boolean\":{\"urlbar.pref_suggest_sponsored\""
		":false,\"urlbar.pref_suggest_topsites\":true,\"urlbar.pref_suggest_nonsponsored\":false,\"urlbar.pref_suggest_data_collection\":false},\"uuid\":{\"legacy.telemetry.client_id\":\"e84f4b7b-8d91-483a-9aa4-2d9b47c1055c\"},\"quantity\":{\"urlbar.pref_max_results\":10}},\"events\":[{\"timestamp\":0,\"category\":\"fog.validation\",\"name\":\"validate_early_event\"},{\"timestamp\":986,\"category\":\"webcompatreporting\",\"name\":\"reason_dropdown\",\"extra\":{\"setting\":\"required\"}},{\"timestamp\":2033"
		",\"category\":\"nimbus_events\",\"name\":\"validation_failed\",\"extra\":{\"reason\":\"invalid-feature\",\"experiment\":\"next-generation-accessibility-engine-powering-screen-readers\",\"feature\":\"accessibilityCache\"}},{\"timestamp\":2034,\"category\":\"nimbus_events\",\"name\":\"is_ready\"}]}", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	web_custom_request("49541e6e-59e7-4544-8b9e-97e851b1744d", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/baseline/1/49541e6e-59e7-4544-8b9e-97e851b1744d", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t87.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":10,\"start_time\":\"2024-02-24T09:58:22.000+05:30\",\"end_time\":\"2024-02-24T09:59:08.014+05:30\",\"reason\":\"dirty_startup\",\"experiments\":{\"device-migration-q4-spotlights-remaining-population\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"backgroundupdate-enable-unelevated-installations-rollout-3-release\":{\"branch\":\"enabled\",\""
		"extra\":{\"type\":\"nimbus-rollout\"}},\"add-an-image-to-pdf-with-alt-text-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"extensions-migration-in-import-wizard-116-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"launch-firefox-on-os-restart-treatment-a-rollout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"fox-guide-reader-mode-existing-user-part-2\":{\"branch\":\"treatment-d\",\"extra\":{\"type\":\"nimbus-nimbus"
		"\"}},\"mozillaaccounts-toolbar-button-default-visibility-existing-user\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"picture-in-picture-first-time-use-callout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"upgrade-spotlight-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"spocs-endpoint-rollout-release\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"ech-roll-out\":{\"branch\":\"rollout\",\"extra"
		"\":{\"type\":\"nimbus-rollout\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"56.1.0\",\"windows_build_number\":19045,\"build_date\":\"1970-01-01T00:00:00+00:00\",\"first_run_date\":\"2023-02-13+05:30\",\"app_build\":\"20240213221259\",\"architecture\":\"x86_64\",\"os\":\"Windows\",\"locale\":\"en-GB\",\"os_version\":\"10.0\",\"app_display_version\":\"123.0\",\"app_channel\":\"release\",\"client_id\":\"b15c2122-a8ac-496f-a186-095bffc440f6\"},\"metrics\":{\"labeled_counter\":{\""
		"glean.validation.pings_submitted\":{\"baseline\":1,\"events\":1}},\"uuid\":{\"legacy.telemetry.client_id\":\"e84f4b7b-8d91-483a-9aa4-2d9b47c1055c\"},\"counter\":{\"browser.engagement.uri_count\":1},\"datetime\":{\"glean.validation.first_run_hour\":\"2023-02-13T17+05:30\"}}}", 
		LAST);

	web_custom_request("a3bceff8-f774-4508-aeaf-429e3488a3b0", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/pageload/1/a3bceff8-f774-4508-aeaf-429e3488a3b0", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t88.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":2,\"start_time\":\"2024-02-24T09:58:22.000+05:30\",\"end_time\":\"2024-02-24T09:59:08.037+05:30\",\"reason\":\"startup\"},\"client_info\":{\"telemetry_sdk_build\":\"56.1.0\",\"windows_build_number\":19045,\"app_build\":\"20240213221259\",\"first_run_date\":\"2023-02-13+05:30\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\"app_display_version\":\"123.0\",\"locale\":\"en-GB\",\"app_channel\":\"release\",\"os\":\"Windows\",\"architecture\":\"x86_64\",\"os_version\":\""
		"10.0\"},\"events\":[{\"timestamp\":0,\"category\":\"perf\",\"name\":\"page_load\",\"extra\":{\"http_ver\":\"1\",\"dns_lookup_time\":\"48\",\"response_time\":\"3159\",\"fcp_time\":\"4493\",\"load_type\":\"NORMAL\",\"load_time\":\"5449\",\"js_exec_time\":\"3\",\"lcp_time\":\"4453\"}}]}", 
		LAST);

	web_custom_request("570c3f3d-581d-4246-b07c-9a382999dda1", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/newtab/1/570c3f3d-581d-4246-b07c-9a382999dda1", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t89.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":10,\"start_time\":\"2024-02-24T09:58:22.000+05:30\",\"end_time\":\"2024-02-24T09:59:08.102+05:30\",\"reason\":\"component_init\"},\"client_info\":{\"telemetry_sdk_build\":\"56.1.0\",\"client_id\":\"b15c2122-a8ac-496f-a186-095bffc440f6\",\"windows_build_number\":19045,\"app_build\":\"20240213221259\",\"architecture\":\"x86_64\",\"os\":\"Windows\",\"app_display_version\":\"123.0\",\"locale\":\"en-GB\",\"app_channel\":\"release\",\"os_version\":\"10.0\",\"build_date\":\""
		"1970-01-01T00:00:00+00:00\",\"first_run_date\":\"2023-02-13+05:30\"},\"metrics\":{\"boolean\":{\"newtab.search.enabled\":true,\"pocket.sponsored_stories_enabled\":true,\"pocket.enabled\":true,\"pocket.is_signed_in\":false,\"topsites.enabled\":true,\"topsites.sponsored_enabled\":true},\"string_list\":{\"newtab.blocked_sponsors\":[]},\"string\":{\"newtab.newtab_category\":\"enabled\",\"newtab.locale\":\"en-GB\",\"newtab.homepage_category\":\"enabled\"},\"quantity\":{\"topsites.rows\":1}}}", 
		LAST);

	web_custom_request("bf5d6164-ccb4-4567-a4b2-707b9b2c058b", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/baseline/1/bf5d6164-ccb4-4567-a4b2-707b9b2c058b", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t90.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":11,\"start_time\":\"2024-02-24T09:59:08.000+05:30\",\"end_time\":\"2024-02-24T09:59:08.190+05:30\",\"reason\":\"active\",\"experiments\":{\"upgrade-spotlight-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"picture-in-picture-first-time-use-callout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\",\"extra\":{\"type\":\"nimbus-rollout\"}},\""
		"extensions-migration-in-import-wizard-116-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"device-migration-q4-spotlights-remaining-population\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"mozillaaccounts-toolbar-button-default-visibility-existing-user\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"launch-firefox-on-os-restart-treatment-a-rollout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\""
		"ech-roll-out\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"backgroundupdate-enable-unelevated-installations-rollout-3-release\":{\"branch\":\"enabled\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"fox-guide-reader-mode-existing-user-part-2\":{\"branch\":\"treatment-d\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"add-an-image-to-pdf-with-alt-text-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"spocs-endpoint-rollout-release\":{\"branch\":\"control\","
		"\"extra\":{\"type\":\"nimbus-rollout\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"56.1.0\",\"client_id\":\"b15c2122-a8ac-496f-a186-095bffc440f6\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\"first_run_date\":\"2023-02-13+05:30\",\"architecture\":\"x86_64\",\"app_display_version\":\"123.0\",\"os\":\"Windows\",\"app_build\":\"20240213221259\",\"locale\":\"en-GB\",\"os_version\":\"10.0\",\"app_channel\":\"release\",\"windows_build_number\":19045},\"metrics\":{\"uuid\":{\""
		"legacy.telemetry.client_id\":\"e84f4b7b-8d91-483a-9aa4-2d9b47c1055c\"},\"labeled_counter\":{\"glean.validation.pings_submitted\":{\"baseline\":1,\"newtab\":1,\"pageload\":1}},\"datetime\":{\"glean.validation.first_run_hour\":\"2023-02-13T17+05:30\"}}}", 
		LAST);

	web_custom_request("ocsp.r2m03.amazontrust.com", 
		"URL=http://ocsp.r2m03.amazontrust.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t91.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x07R6V$\\x8B\\xBD\\x9E\\xF5\\x90\\xD5\\xE6|\\xE1\\xC6\\xA7", 
		LAST);

	web_custom_request("ocsp.r2m02.amazontrust.com", 
		"URL=http://ocsp.r2m02.amazontrust.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t92.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x0F2`\\x95\\xE2\\xEC\\x99\\x9B\\xF9z\\x07\\xA7\\xA0\\x1D\\xC6\\xCC", 
		LAST);

	web_custom_request("pageviews", 
		"URL=https://blazemeter.datapipe.prodperfect.com/v1/3.0/projects/lXviifSA1NskA4wsG9N6WoWg/events/pageviews?api_key=8RWMCGFX4X0IRY1GHWDM3HM5WDSJF9LP62BSDULOL3XK7WAIFGDB7EU526O1A0UPLH1S8SJP320LUXJKCHLJX1822GU1KFE80CNW6PXVZ83IOO6LJ731EN164IFVUFMC8DOGYP2MXHN47WGVB192F2PTQRQXCF95OJWAKGOH9S69DZAI5OPJW8QSPDE6LQQ9", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://blazedemo.com/", 
		"Snapshot=t93.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body={\"visitor\":{\"user_id\":null},\"event_uuid\":\"4ef5dfdc-663a-4b40-8faa-9e20f567dc3f\",\"iso_time_full\":\"2024-02-24T04:29:11.931Z\",\"local_time_full\":\"Sat Feb 24 2024 09:59:11 GMT+0530 (India Standard Time)\",\"session\":{\"session_uuid\":\"b3316af3-825c-4417-97e1-dad1d2248582\"},\"tracked_by\":\"prodperfect-keen-tracking-2.0.23\",\"tracker_load_uuid\":\"6bf93cab-3ad4-4cbf-b692-2db1693ee1b5\",\"tracker_loaded_at\":\"2024-02-24T04:29:11.928Z\",\"prodperfect_test_data\":null,\"user\":{\""
		"uuid\":\"50e5d2c7-ae4d-452a-8c01-b7fe45935d5a\"},\"page\":{\"title\":\"BlazeDemo\",\"description\":\"BlazeMeter demo app\",\"scroll_state\":{\"pixel\":595,\"pixel_max\":595,\"ratio\":1,\"ratio_max\":1},\"time_on_page\":0,\"time_on_page_ms\":4},\"ip_address\":\"${keen.ip}\",\"geo\":{},\"user_agent\":\"${keen.user_agent}\",\"tech\":{\"profile\":{\"cookies\":true,\"codeName\":\"Mozilla\",\"description\":\"BlazeMeter demo app\",\"language\":\"en-GB\",\"name\":\"Netscape\",\"online\":true,\"platform\""
		":\"Win32\",\"useragent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0\",\"version\":\"5.0 (Windows)\",\"screen\":{\"height\":720,\"width\":1280,\"colorDepth\":24,\"pixelDepth\":24,\"availHeight\":680,\"availWidth\":1280,\"orientation\":{\"angle\":0,\"type\":\"landscape\"}},\"window\":{\"height\":595,\"width\":1280,\"scrollHeight\":595,\"ratio\":{\"height\":0.88,\"width\":1}}}},\"url\":{\"full\":\"https://blazedemo.com/\",\"info\":{}},\"referrer\":{\"full\":\""
		"\",\"info\":{}},\"time\":{\"local\":{},\"utc\":{}},\"keen\":{\"timestamp\":\"2024-02-24T04:29:11.932Z\",\"addons\":[{\"name\":\"keen:ua_parser\",\"input\":{\"ua_string\":\"user_agent\"},\"output\":\"tech\"},{\"name\":\"keen:url_parser\",\"input\":{\"url\":\"url.full\"},\"output\":\"url.info\"},{\"name\":\"keen:url_parser\",\"input\":{\"url\":\"referrer.full\"},\"output\":\"referrer.info\"},{\"name\":\"keen:date_time_parser\",\"input\":{\"date_time\":\"keen.timestamp\"},\"output\":\"time.utc\"},{\""
		"name\":\"keen:date_time_parser\",\"input\":{\"date_time\":\"local_time_full\"},\"output\":\"time.local\"},{\"name\":\"keen:ip_to_geo\",\"input\":{\"ip\":\"ip_address\",\"remove_ip_property\":false},\"output\":\"geo\"}]}}", 
		LAST);

	return 0;
}
