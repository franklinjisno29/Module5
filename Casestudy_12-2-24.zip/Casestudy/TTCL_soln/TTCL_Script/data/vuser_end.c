vuser_end()
{

	lr_think_time(17);

	web_url("logout", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/logout", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("logout_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/users/logout", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/logout", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_url("thinking-tester-contact-list.herokuapp.com_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/logout", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	web_concurrent_start(NULL);

	web_url("thinkingTesterLogo.png_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/img/thinkingTesterLogo.png", 
		"TargetFrame=", 
		"Resource=1", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t22.inf", 
		LAST);

	web_url("login.js", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/js/login.js", 
		"TargetFrame=", 
		"Resource=1", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t23.inf", 
		LAST);

	web_concurrent_end(NULL);

	return 0;
}