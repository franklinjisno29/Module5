Action()
{

	/* click home */

	web_custom_request("clicks", 
		"URL=https://blazemeter.datapipe.prodperfect.com/v1/3.0/projects/lXviifSA1NskA4wsG9N6WoWg/events/clicks?api_key=8RWMCGFX4X0IRY1GHWDM3HM5WDSJF9LP62BSDULOL3XK7WAIFGDB7EU526O1A0UPLH1S8SJP320LUXJKCHLJX1822GU1KFE80CNW6PXVZ83IOO6LJ731EN164IFVUFMC8DOGYP2MXHN47WGVB192F2PTQRQXCF95OJWAKGOH9S69DZAI5OPJW8QSPDE6LQQ9", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://blazedemo.com/", 
		"Snapshot=t94.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body={\"visitor\":{\"user_id\":null},\"event_uuid\":\"533fc751-3d44-4ba9-8160-7117d61c539f\",\"iso_time_full\":\"2024-02-24T04:29:40.230Z\",\"local_time_full\":\"Sat Feb 24 2024 09:59:40 GMT+0530 (India Standard Time)\",\"session\":{\"session_uuid\":\"b3316af3-825c-4417-97e1-dad1d2248582\"},\"tracked_by\":\"prodperfect-keen-tracking-2.0.23\",\"tracker_load_uuid\":\"6bf93cab-3ad4-4cbf-b692-2db1693ee1b5\",\"tracker_loaded_at\":\"2024-02-24T04:29:11.928Z\",\"prodperfect_test_data\":null,\"user\":{\""
		"uuid\":\"50e5d2c7-ae4d-452a-8c01-b7fe45935d5a\"},\"page\":{\"title\":\"BlazeDemo\",\"description\":\"BlazeMeter demo app\",\"scroll_state\":{\"pixel\":595,\"pixel_max\":595,\"ratio\":1,\"ratio_max\":1},\"time_on_page\":28,\"time_on_page_ms\":28302},\"ip_address\":\"${keen.ip}\",\"geo\":{},\"user_agent\":\"${keen.user_agent}\",\"tech\":{\"profile\":{\"cookies\":true,\"codeName\":\"Mozilla\",\"description\":\"BlazeMeter demo app\",\"language\":\"en-GB\",\"name\":\"Netscape\",\"online\":true,\""
		"platform\":\"Win32\",\"useragent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0\",\"version\":\"5.0 (Windows)\",\"screen\":{\"height\":720,\"width\":1280,\"colorDepth\":24,\"pixelDepth\":24,\"availHeight\":680,\"availWidth\":1280,\"orientation\":{\"angle\":0,\"type\":\"landscape\"}},\"window\":{\"height\":595,\"width\":1280,\"scrollHeight\":595,\"ratio\":{\"height\":0.88,\"width\":1}}}},\"url\":{\"full\":\"https://blazedemo.com/\",\"info\":{}},\"referrer\":{\""
		"full\":\"\",\"info\":{}},\"time\":{\"local\":{},\"utc\":{}},\"keen\":{\"timestamp\":\"2024-02-24T04:29:40.230Z\",\"addons\":[{\"name\":\"keen:ua_parser\",\"input\":{\"ua_string\":\"user_agent\"},\"output\":\"tech\"},{\"name\":\"keen:url_parser\",\"input\":{\"url\":\"url.full\"},\"output\":\"url.info\"},{\"name\":\"keen:url_parser\",\"input\":{\"url\":\"referrer.full\"},\"output\":\"referrer.info\"},{\"name\":\"keen:date_time_parser\",\"input\":{\"date_time\":\"keen.timestamp\"},\"output\":\""
		"time.utc\"},{\"name\":\"keen:date_time_parser\",\"input\":{\"date_time\":\"local_time_full\"},\"output\":\"time.local\"},{\"name\":\"keen:ip_to_geo\",\"input\":{\"ip\":\"ip_address\",\"remove_ip_property\":false},\"output\":\"geo\"}]},\"element\":{\"class\":\"brand\",\"href\":\"https://blazedemo.com/home\",\"id\":null,\"name\":null,\"all_attrs\":{\"class\":\"brand\",\"href\":\"home\",\"unique_selector\":\".navbar-inner > .container > :nth-child(3)\"},\"node_name\":\"A\",\"tag_name\":\"A\",\"text\""
		":null,\"title\":null,\"type\":null,\"n_parents\":[{\"class\":\"container\",\"href\":null,\"id\":null,\"name\":null,\"all_attrs\":{\"class\":\"container\",\"unique_selector\":\".navbar-inner > .container\"},\"node_name\":\"DIV\",\"tag_name\":\"DIV\",\"text\":null,\"title\":null,\"type\":null,\"nth_parent\":1},{\"class\":\"navbar-inner\",\"href\":null,\"id\":null,\"name\":null,\"all_attrs\":{\"class\":\"navbar-inner\",\"unique_selector\":\".navbar-inner\"},\"node_name\":\"DIV\",\"tag_name\":\"DIV\","
		"\"text\":null,\"title\":null,\"type\":null,\"nth_parent\":2},{\"class\":\"navbar navbar-inverse\",\"href\":null,\"id\":null,\"name\":null,\"all_attrs\":{\"class\":\"navbar navbar-inverse\",\"unique_selector\":\".navbar\"},\"node_name\":\"DIV\",\"tag_name\":\"DIV\",\"text\":null,\"title\":null,\"type\":null,\"nth_parent\":3},{\"class\":null,\"href\":null,\"id\":null,\"name\":null,\"all_attrs\":{\"unique_selector\":\"body\"},\"node_name\":\"BODY\",\"tag_name\":\"BODY\",\"text\":null,\"title\":null,"
		"\"type\":null,\"nth_parent\":4},{\"class\":null,\"href\":null,\"id\":null,\"name\":null,\"all_attrs\":{\"lang\":\"en\",\"unique_selector\":\"html\"},\"node_name\":\"HTML\",\"tag_name\":\"HTML\",\"text\":null,\"title\":null,\"type\":null,\"nth_parent\":5},{\"class\":null,\"href\":null,\"id\":null,\"name\":null,\"all_attrs\":{},\"node_name\":\"#document\",\"text\":null,\"title\":null,\"type\":null,\"nth_parent\":6}],\"selector\":\"body > div:eq(0) > div > div > a:eq(2)\",\"text_content\":\""
		"---REDACTED---\",\"cursor\":\"pointer\",\"x_position\":171,\"y_position\":1}}", 
		LAST);

	web_custom_request("pageunloads", 
		"URL=https://blazemeter.datapipe.prodperfect.com/v1/3.0/projects/lXviifSA1NskA4wsG9N6WoWg/events/pageunloads?api_key=8RWMCGFX4X0IRY1GHWDM3HM5WDSJF9LP62BSDULOL3XK7WAIFGDB7EU526O1A0UPLH1S8SJP320LUXJKCHLJX1822GU1KFE80CNW6PXVZ83IOO6LJ731EN164IFVUFMC8DOGYP2MXHN47WGVB192F2PTQRQXCF95OJWAKGOH9S69DZAI5OPJW8QSPDE6LQQ9", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://blazedemo.com/", 
		"Snapshot=t95.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body={\"visitor\":{\"user_id\":null},\"event_uuid\":\"5b60faa9-0788-4015-8d17-c6aada8e5452\",\"iso_time_full\":\"2024-02-24T04:29:40.247Z\",\"local_time_full\":\"Sat Feb 24 2024 09:59:40 GMT+0530 (India Standard Time)\",\"session\":{\"session_uuid\":\"b3316af3-825c-4417-97e1-dad1d2248582\"},\"tracked_by\":\"prodperfect-keen-tracking-2.0.23\",\"tracker_load_uuid\":\"6bf93cab-3ad4-4cbf-b692-2db1693ee1b5\",\"tracker_loaded_at\":\"2024-02-24T04:29:11.928Z\",\"prodperfect_test_data\":null,\"user\":{\""
		"uuid\":\"50e5d2c7-ae4d-452a-8c01-b7fe45935d5a\"},\"page\":{\"title\":\"BlazeDemo\",\"description\":\"BlazeMeter demo app\",\"scroll_state\":{\"pixel\":595,\"pixel_max\":595,\"ratio\":1,\"ratio_max\":1},\"time_on_page\":28,\"time_on_page_ms\":28319},\"ip_address\":\"${keen.ip}\",\"geo\":{},\"user_agent\":\"${keen.user_agent}\",\"tech\":{\"profile\":{\"cookies\":true,\"codeName\":\"Mozilla\",\"description\":\"BlazeMeter demo app\",\"language\":\"en-GB\",\"name\":\"Netscape\",\"online\":true,\""
		"platform\":\"Win32\",\"useragent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0\",\"version\":\"5.0 (Windows)\",\"screen\":{\"height\":720,\"width\":1280,\"colorDepth\":24,\"pixelDepth\":24,\"availHeight\":680,\"availWidth\":1280,\"orientation\":{\"angle\":0,\"type\":\"landscape\"}},\"window\":{\"height\":595,\"width\":1280,\"scrollHeight\":595,\"ratio\":{\"height\":0.88,\"width\":1}}}},\"url\":{\"full\":\"https://blazedemo.com/\",\"info\":{}},\"referrer\":{\""
		"full\":\"\",\"info\":{}},\"time\":{\"local\":{},\"utc\":{}},\"keen\":{\"timestamp\":\"2024-02-24T04:29:40.247Z\",\"addons\":[{\"name\":\"keen:ua_parser\",\"input\":{\"ua_string\":\"user_agent\"},\"output\":\"tech\"},{\"name\":\"keen:url_parser\",\"input\":{\"url\":\"url.full\"},\"output\":\"url.info\"},{\"name\":\"keen:url_parser\",\"input\":{\"url\":\"referrer.full\"},\"output\":\"referrer.info\"},{\"name\":\"keen:date_time_parser\",\"input\":{\"date_time\":\"keen.timestamp\"},\"output\":\""
		"time.utc\"},{\"name\":\"keen:date_time_parser\",\"input\":{\"date_time\":\"local_time_full\"},\"output\":\"time.local\"},{\"name\":\"keen:ip_to_geo\",\"input\":{\"ip\":\"ip_address\",\"remove_ip_property\":false},\"output\":\"geo\"}]}}", 
		LAST);

	web_add_cookie("prodperfect_session={%22session_uuid%22:%22b3316af3-825c-4417-97e1-dad1d2248582%22}; DOMAIN=blazedemo.com");

	web_add_cookie("keen={%22uuid%22:%2250e5d2c7-ae4d-452a-8c01-b7fe45935d5a%22%2C%22initialReferrer%22:null}; DOMAIN=blazedemo.com");

	web_url("home", 
		"URL=https://blazedemo.com/home", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/", 
		"Snapshot=t96.inf", 
		"Mode=HTML", 
		LAST);

	web_url("canonical.html_4", 
		"URL=http://detectportal.firefox.com/canonical.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t97.inf", 
		"Mode=HTML", 
		LAST);

	web_url("canonical.html_5", 
		"URL=http://detectportal.firefox.com/canonical.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t98.inf", 
		"Mode=HTML", 
		LAST);

	web_url("canonical.html_6", 
		"URL=http://detectportal.firefox.com/canonical.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t99.inf", 
		"Mode=HTML", 
		LAST);

	web_url("canonical.html_7", 
		"URL=http://detectportal.firefox.com/canonical.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t100.inf", 
		"Mode=HTML", 
		LAST);

	web_submit_data("login", 
		"Action=https://blazedemo.com/login", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t101.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=_token", "Value=vuGEGI5MJVjwxjY2sBbISCzhMYXEqA6Fhy55xKlw", ENDITEM, 
		"Name=email", "Value=frankjisno@gmail.com", ENDITEM, 
		"Name=password", "Value=12345678", ENDITEM, 
		LAST);

	return 0;
}
